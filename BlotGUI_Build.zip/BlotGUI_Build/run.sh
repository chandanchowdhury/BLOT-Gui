#!/bin/sh
sys_name="`uname -s`"

echo $sys_name

if [ $sys_name = "Linux" ]; then
    echo "Executing Linux version...."
    java -jar BlotGUI_Linux.jar
elif [ $sys_name = "Darwin" ]; then
    echo "Executing OSX version..."
    java -XstartOnFirstThread -jar BlotGUI_OSX.jar
fi
